<div class="splash-footer">
    &copy; 2024 - <?php echo date ('Y');?>
    Online Railway Reservation System | Developed By dieudonne norman
</div>
